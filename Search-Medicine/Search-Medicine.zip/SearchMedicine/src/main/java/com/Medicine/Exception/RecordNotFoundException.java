package com.Medicine.Exception;

public class RecordNotFoundException extends Exception{

	public RecordNotFoundException(String msg) {

		super(msg);
	}
}
